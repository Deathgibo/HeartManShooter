#pragma once

const int MAX_DIRECTIONAL_LIGHTS = 1;
const int MAX_POINT_LIGHTS = 7;
const int MAX_SPOT_LIGHTS = 1;

